# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('wad_Budget', '0002_remove_budget_campaignbudget'),
    ]

    operations = [
        migrations.AddField(
            model_name='budget',
            name='budgetdeliverymethod',
            field=models.CharField(default='STANDARD', max_length=20, choices=[(b'STANDARD', b'Standard'), (b'ACCELERATED', b'Accelerated'), (b'TESTING', b'Testing')]),
            preserve_default=False,
        ),
    ]

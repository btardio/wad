# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('wad_Campaign', '0002_auto_20161105_1915'),
    ]

    operations = [
        migrations.CreateModel(
            name='Budget',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('budgetid', models.BigIntegerField(unique=True)),
                ('budgetname', models.CharField(help_text=b'Budget name', max_length=255)),
                ('budgetamount', models.BigIntegerField()),
                ('budgetstatus', models.CharField(max_length=20, choices=[(b'ENABLED', b'Enabled'), (b'PAUSED', b'Paused'), (b'REMOVED', b'Removed'), (b'TESTING', b'Testing')])),
                ('internalbudgetrefreshdate', models.DateTimeField(auto_now_add=True)),
                ('internalbudgetcreationdate', models.DateTimeField(auto_now_add=True)),
                ('campaignbudget', models.ForeignKey(related_query_name=b'campaign', related_name='campaign', to='wad_Campaign.Campaign')),
            ],
        ),
    ]

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('wad_Budget', '0002_remove_budget_campaignbudget'),
        ('wad_Campaign', '0002_auto_20161105_1915'),
    ]

    operations = [
        migrations.AddField(
            model_name='campaign',
            name='campaignbudget',
            field=models.ForeignKey(related_query_name=b'budget', related_name='budget', on_delete=django.db.models.deletion.SET_NULL, to='wad_Budget.Budget', null=True),
        ),
    ]

# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Campaign',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('campaignid', models.BigIntegerField(unique=True)),
                ('campaignstatus', models.CharField(max_length=20, choices=[(b'ENABLED', b'Enabled'), (b'PAUSED', b'Paused'), (b'REMOVED', b'Removed')])),
                ('campaignname', models.CharField(help_text=b'Campaign name', max_length=255)),
                ('internalcampaigncreationdate', models.DateTimeField(auto_now_add=True)),
                ('internalcampaignrefreshdate', models.DateTimeField(auto_now=True)),
            ],
        ),
    ]
